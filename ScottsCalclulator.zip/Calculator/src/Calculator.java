public class Calculator {

public static double calculate(double operand1, double operand2, char operator) {


double result = 0.0;

switch (operator) {

// calculating result and storing in result variable

case '+':
result = operand1 + operand2;
break;
case '-':
result = operand1 - operand2;
break;
case '*':
result = operand1 * operand2;
break;
case '/':
result = operand1 / operand2;
break;
}

return result;
}

public static void main(String[] args) {

// testing 

System.out.println("8 + 4 = " + calculate(8, 4, '+'));
System.out.println("8 - 4 = " + calculate(8, 4, '-'));
System.out.println("8 * 4 = " + calculate(8, 4, '*'));
System.out.println("8 / 4 = " + calculate(8, 4, '/'));
}
}

